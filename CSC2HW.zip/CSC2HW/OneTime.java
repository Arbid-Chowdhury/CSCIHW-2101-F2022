package CSC2HW;

public class OneTime extends Appt{
    public OneTime(int day, int month, int year, String desc)
    {
        super(day, month, year, desc);
    }
}
