package CSC2HW4;

public class MathGames {
    public static void main(String[] args) {
        System.out.println("Start of MathGames");
        L1 level1  = new L1();
        L2 level2 = new L2();
        L3 level3 = new L3();


    }
}
